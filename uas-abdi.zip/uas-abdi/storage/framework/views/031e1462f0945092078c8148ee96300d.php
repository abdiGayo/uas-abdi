

<?php $__env->startSection('content'); ?>

<h2>Tambah Nasabah</h2>

<form action="<?php echo e(url('users')); ?>" method="post">
    <?php echo csrf_field(); ?>


    <div class="mb-3">
        <label for="">Id</label>
        <input type="text" name="user_id" id="" class="form-control">
    </div>

    <div class="mb-3">
        <label for="">E-Mail</label>
        <input type="text" name="user_email" id="" class="form-control">
    </div>

    <div class="mb-3">
        <label for="">No-Seri</label>
        <input type="text" name="user_seri" id="" class="form-control">
    </div>

    <div class="mb-3">
        <label for="">Nama</label>
        <input type="text" name="user_nama" id="" class="form-control">
    </div>

    <div class="mb-3">
        <input type="submit" value="SIMPAN" class="btn btn-primary">
        
    </div>


</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pbwl-laravel-hairulamri\pbwl-laravel-hairulamri\resources\views/users/create.blade.php ENDPATH**/ ?>