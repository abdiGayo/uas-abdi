@extends('layouts.app')

@section('content')

<h2>Tambah Nasabah</h2>

<form action="{{ url('users') }}" method="post">
    @csrf


    <div class="mb-3">
        <label for="">Id</label>
        <input type="text" name="user_id" id="" class="form-control">
    </div>

    <div class="mb-3">
        <label for="">E-Mail</label>
        <input type="text" name="user_email" id="" class="form-control">
    </div>

    <div class="mb-3">
        <label for="">No-Seri</label>
        <input type="text" name="user_seri" id="" class="form-control">
    </div>

    <div class="mb-3">
        <label for="">Nama</label>
        <input type="text" name="user_nama" id="" class="form-control">
    </div>

    <div class="mb-3">
        <input type="submit" value="SIMPAN" class="btn btn-primary">
        
    </div>


</form>

@endsection