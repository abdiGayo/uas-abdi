@extends('layouts.app')

@section('content')

<h2>Edit Nasabah</h2>

<form action="{{ url('users/' . $row->user_id) }}" method="post">
    
    <input type="hidden" name="_method" value="PATCH">
    @csrf


    <div class="mb-3">
        <label for="">Id</label>
        <input type="text" name="user_id" id="" class="form-control" value="{{ $row->user_id}}"> </div>

    <div class="mb-3">
        <label for="">E-Mail</label>
        <input type="text" name="user_email" id="" class="form-control" value="{{ $row->user_email}}">
    </div>

    <div class="mb-3">
        <label for="">No - Seri</label>
        <input type="text" name="user_seri" id="" class="form-control" value="{{ $row->user_seri}}">
    </div>

    <div class="mb-3">
        <label for="">Nama</label>
        <input type="text" name="user_nama" id="" class="form-control"value="{{ $row->user_nama}}">
    </div>

    <div class="mb-3">
        <input type="submit" value="UPDATE" class="btn btn-primary">
        
    </div>


</form>

@endsection